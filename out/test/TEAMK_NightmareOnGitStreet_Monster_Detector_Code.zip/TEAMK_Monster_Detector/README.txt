Team K "Nightmare on Git Street": Monster Detector

Run all nine detectors on one data split and build the paste-ready submission CSV:

    uv sync
    uv run python -m detector test        # or: training, predict

Input: the organisers' folders copied into data/ (General Files, Training, Test, Predict).
Output: out/<stage>/<monster>.csv per monster, plus out/<stage>/<STAGE>_combined.csv
(columns Monster Type,P_ID) that is pasted into the MANUAL COMBINED sheet.
On TEST it takes about 18 s.

  detector/load.py       DuckDB views over the CSVs + a merged LMS/video timeline
  detector/<monster>.py  one rule per monster (rules and rejected variants: docs/competition/monster-guide.md)
  detector/combine.py    merges the per-monster CSVs and flags any missing type
  detector/score.py      precision/recall against the HUNT answers
  experiments/werewolf/  how the Werewolf rule was fitted
