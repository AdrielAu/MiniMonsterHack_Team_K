Team K "Nightmare on Git Street": PREDICT code

Flag students starting to turn into one of the 5 behavioural monsters, using only activity up to 14 Nov 2023:

    uv sync
    uv run python -m detector.predict             # PREDICT data -> out/predict/PREDICT_combined.csv
    uv run python -m detector.predict training    # backtest the rules against the HUNT answers

Input: the organisers' folders copied into data/ (General Files, Training, Predict), plus data/HUNT_P_IDs_corrected.csv for the backtest.

  detector/load.py       DuckDB views over the CSVs; connect(split, cutoff="2023-11-14") drops later activity
  detector/predict.py    the 5 early-warning rules (Ghost, Zombie, Vampire, Werewolf, Web Crawler)
  detector/backtest.py   scores rules on training cut at 14 Nov against the HUNT answers
  docs/competition/predict.md  chosen rules, backtest scores and rejected candidates
